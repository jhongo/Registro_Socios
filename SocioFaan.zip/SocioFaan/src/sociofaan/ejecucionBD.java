package sociofaan;

public class ejecucionBD { 
    public static void main(String[] args) {
        conexionBD co = new conexionBD();
        co.conectar();
    }
    
}
